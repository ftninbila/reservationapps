package com.example.reservationapps;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ReservationActivity extends AppCompatActivity {

    private EditText eventIdEditText;
    private EditText reservationDateEditText;
    private Button addButton;
    private Button updateButton;
    private Button cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        eventIdEditText = findViewById(R.id.eventIdEditText);
        reservationDateEditText = findViewById(R.id.reservationDateEditText);
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        cancelButton = findViewById(R.id.cancelButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageReservation("add");
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageReservation("update");
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manageReservation("cancel");
            }
        });
    }

    private void manageReservation(final String action) {
        final String eventId = eventIdEditText.getText().toString();
        final String reservationDate = reservationDateEditText.getText().toString();

        class ManageReservationTask extends AsyncTask<Void, Void, String> {

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL("http://10.0.2.2/reservationapps/manage_reservation.php");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);

                    String data = URLEncoder.encode("action", "UTF-8") + "=" + URLEncoder.encode(action, "UTF-8") +
                            "&" + URLEncoder.encode("event_id", "UTF-8") + "=" + URLEncoder.encode(eventId, "UTF-8") +
                            "&" + URLEncoder.encode("reservation_date", "UTF-8") + "=" + URLEncoder.encode(reservationDate, "UTF-8");

                    if (action.equals("update") || action.equals("cancel")) {
                        // Add reservation_id if the action is update or cancel
                        String reservationId = ""; // Assume you retrieve reservationId from somewhere
                        data += "&" + URLEncoder.encode("reservation_id", "UTF-8") + "=" + URLEncoder.encode(reservationId, "UTF-8");
                    }

                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(data);
                    writer.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    writer.close();
                    reader.close();

                    return response.toString();
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        String status = jsonObject.getString("status");

                        if (status.equals("success")) {
                            Toast.makeText(ReservationActivity.this, "Action successful", Toast.LENGTH_SHORT).show();
                        } else {
                            String message = jsonObject.getString("message");
                            Toast.makeText(ReservationActivity.this, "Action failed: " + message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(ReservationActivity.this, "Failed to connect to server", Toast.LENGTH_SHORT).show();
                }
            }
        }

        ManageReservationTask task = new ManageReservationTask();
        task.execute();
    }
}
