<?php
header("Content-Type: application/json; charset=UTF-8");

$servername = "localhost";
$username = "root"; // Default MySQL username
$password = ""; // Default MySQL password
$dbname = "reservation_db"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(array("status" => "error", "message" => "Connection failed: " . $conn->connect_error));
    exit();
}

// Read JSON input
$input = file_get_contents("php://input");

// Check if input is valid JSON
if (json_decode($input) === null) {
    echo json_encode(array("status" => "error", "message" => "Invalid JSON input"));
    exit();
}

$data = json_decode($input, true);
$user = $data['username'];
$pass = $data['password'];

// Prepare SQL statement
$sql = "SELECT * FROM Users WHERE username = ? AND password = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    echo json_encode(array("status" => "error", "message" => "SQL statement preparation failed: " . $conn->error));
    exit();
}

$stmt->bind_param("ss", $user, $pass);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    echo json_encode(array("status" => "success"));
} else {
    echo json_encode(array("status" => "fail", "message" => "Invalid username or password"));
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
