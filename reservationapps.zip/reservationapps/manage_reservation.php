<?php
header("Content-Type: application/json");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reservation_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(array("status" => "error", "message" => "Connection failed: " . $conn->connect_error)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input = file_get_contents("php://input");
    parse_str($input, $data);

    $action = isset($data['action']) ? $data['action'] : '';
    $eventId = isset($data['event_id']) ? $data['event_id'] : '';
    $reservationDate = isset($data['reservation_date']) ? $data['reservation_date'] : '';
    $reservationId = isset($data['reservation_id']) ? $data['reservation_id'] : null;
    $userId = isset($data['user_id']) ? $data['user_id'] : 1; // Default user ID if not provided

    if ($action == "add") {
        if (!empty($userId) && !empty($eventId) && !empty($reservationDate)) {
            $stmt = $conn->prepare("INSERT INTO reservations (user_id, event_id, reservation_date) VALUES (?, ?, ?)");
            if ($stmt === false) {
                error_log("Prepare failed: " . $conn->error);
                die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
            }
            $stmt->bind_param("iis", $userId, $eventId, $reservationDate);

            if ($stmt->execute()) {
                $reservationId = $stmt->insert_id;
                echo json_encode(array("status" => "success", "reservation_id" => $reservationId));
            } else {
                error_log("Execute failed: " . $stmt->error);
                echo json_encode(array("status" => "error", "message" => "Failed to add reservation: " . $stmt->error));
            }
            $stmt->close();
        } else {
            echo json_encode(array("status" => "error", "message" => "Missing data for add action"));
        }
    } elseif ($action == "update") {
        if ($reservationId === null || !$eventId || !$reservationDate) {
            echo json_encode(array("status" => "error", "message" => "Reservation ID, event ID, and reservation date are required for update"));
            exit();
        }

        // Update reservations
        $stmt = $conn->prepare("UPDATE reservations SET event_id=?, reservation_date=? WHERE reservation_id=?");
        if ($stmt === false) {
            error_log("Prepare failed: " . $conn->error);
            die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
        }
        $stmt->bind_param("isi", $eventId, $reservationDate, $reservationId);

        if ($stmt->execute()) {
            // Update events
            $stmt = $conn->prepare("UPDATE events SET event_date=? WHERE event_id=?");
            if ($stmt === false) {
                error_log("Prepare failed: " . $conn->error);
                die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
            }
            $stmt->bind_param("si", $reservationDate, $eventId);

            if ($stmt->execute()) {
                echo json_encode(array("status" => "success"));
            } else {
                error_log("Execute failed: " . $stmt->error);
                echo json_encode(array("status" => "error", "message" => "Failed to update event: " . $stmt->error));
            }
        } else {
            error_log("Execute failed: " . $stmt->error);
            echo json_encode(array("status" => "error", "message" => "Failed to update reservation: " . $stmt->error));
        }
        $stmt->close();
    } elseif ($action == "cancel") {
        if ($reservationId === null) {
            echo json_encode(array("status" => "error", "message" => "Reservation ID is required for cancel"));
            exit();
        }

        // Fetch event ID for the reservation
        $stmt = $conn->prepare("SELECT event_id FROM reservations WHERE reservation_id=?");
        if ($stmt === false) {
            error_log("Prepare failed: " . $conn->error);
            die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
        }
        $stmt->bind_param("i", $reservationId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $eventId = $row['event_id'];
            $stmt->close();

            // Delete reservation
            $stmt = $conn->prepare("DELETE FROM reservations WHERE reservation_id=?");
            if ($stmt === false) {
                error_log("Prepare failed: " . $conn->error);
                die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
            }
            $stmt->bind_param("i", $reservationId);

            if ($stmt->execute()) {
                // Check if any other reservations exist for this event
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM reservations WHERE event_id=?");
                if ($stmt === false) {
                    error_log("Prepare failed: " . $conn->error);
                    die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
                }
                $stmt->bind_param("i", $eventId);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();

                if ($row['count'] == 0) {
                    // No other reservations, delete the event
                    $stmt = $conn->prepare("DELETE FROM events WHERE event_id=?");
                    if ($stmt === false) {
                        error_log("Prepare failed: " . $conn->error);
                        die(json_encode(array("status" => "error", "message" => "Prepare failed: " . $conn->error)));
                    }
                    $stmt->bind_param("i", $eventId);

                    if ($stmt->execute()) {
                        echo json_encode(array("status" => "success", "message" => "Reservation and event deleted"));
                    } else {
                        error_log("Execute failed: " . $stmt->error);
                        echo json_encode(array("status" => "error", "message" => "Failed to delete event: " . $stmt->error));
                    }
                } else {
                    // Other reservations exist, do not delete the event
                    echo json_encode(array("status" => "success", "message" => "Reservation deleted, event still has other reservations"));
                }
            } else {
                error_log("Execute failed: " . $stmt->error);
                echo json_encode(array("status" => "error", "message" => "Failed to delete reservation: " . $stmt->error));
            }
            $stmt->close();
        } else {
            echo json_encode(array("status" => "error", "message" => "Reservation not found"));
        }
    } else {
        echo json_encode(array("status" => "error", "message" => "Invalid action"));
    }
}

$conn->close();
?>
