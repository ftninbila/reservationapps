<?php
$servername = "localhost";
$username = "root";
$password = ""; // Default password is usually empty in XAMPP/WAMP
$dbname = "reservation_db"; // Make sure this matches your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
