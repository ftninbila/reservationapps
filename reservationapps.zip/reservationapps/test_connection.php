<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reservation_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
} else {
    echo "Connection successful";
}

$conn->close();
?>
